using MagicNumbersConsoleMVC.Models;

namespace MagicNumbersConsoleMVCTests
{
    [TestFixture]
    public class MagicNumberInfoTests
    {
        [Test]
        public void GetSixDigitsNumberWithDigitsProductEqualingMagicalNumber_WhenValidNumberExists_ShouldReturnValidResult()
        {
            // Arrange
            int magicNumber = 720; 
            MagicNumberInfo magicNumberInfo = new MagicNumberInfo(magicNumber);

            // Act
            List<int> result = magicNumberInfo.GetSixDigitsNumberWithDigitsProductEqualingMagicalNumber();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsNotEmpty(result);
            foreach (int number in result)
            {
                int product = 1;
                foreach (char digitChar in number.ToString())
                {
                    int digit = int.Parse(digitChar.ToString());
                    product *= digit;
                }
                Assert.AreEqual(magicNumber, product);
            }
        }

        [Test]
        public void Constructor_SavesValuesCorrectly()
        {
            MagicNumberInfo magicNumber = new MagicNumberInfo(10);
            Assert.AreEqual(magicNumber.WholeNumberValue, 10);
        }
    }
}