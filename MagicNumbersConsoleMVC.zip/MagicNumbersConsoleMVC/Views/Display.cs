﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicNumbersConsoleMVC.Views
{
    public class Display
    {
        public Display()
        {
            GetValues();
        }

        public int WholeNumber { get; set; }

        public List<int> SixDigitsNumbersWithDigitsProductEqualingMagicalNumber { get; set; }

        public void ShowSixDigitsNumbersWithDigitsProductEqualingMagicalNumber()
        {
            foreach (var sixDigitNumber in SixDigitsNumbersWithDigitsProductEqualingMagicalNumber)
            {
                Console.Write($"{sixDigitNumber} ");
            }
        }

        private void GetValues()
        {
            WholeNumber = int.Parse(Console.ReadLine());
        }
    }
}
