﻿using MagicNumbersConsoleMVC.Models;
using MagicNumbersConsoleMVC.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicNumbersConsoleMVC.Controllers
{
    public class MagicNumbersController
    {
        private MagicNumberInfo magicalNumberInfo;

        private Display display;

        public MagicNumbersController()
        {
            display = new Display();
            magicalNumberInfo = new MagicNumberInfo(display.WholeNumber);
            display.SixDigitsNumbersWithDigitsProductEqualingMagicalNumber = magicalNumberInfo
                .GetSixDigitsNumberWithDigitsProductEqualingMagicalNumber();
            display.ShowSixDigitsNumbersWithDigitsProductEqualingMagicalNumber();
        }
    }
}
